//
//  RootViewController.h
//  PrefsDemo
//
//  Created by 陶柏同 on 16/8/31.
//  Copyright © 2016年 LaoTao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController

@end
