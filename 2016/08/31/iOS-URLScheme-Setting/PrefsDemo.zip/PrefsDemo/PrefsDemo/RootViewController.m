//
//  RootViewController.m
//  PrefsDemo
//
//  Created by 陶柏同 on 16/8/31.
//  Copyright © 2016年 LaoTao. All rights reserved.
//

#import "RootViewController.h"

@interface RootViewController ()
{
    NSArray *_dataSource;
}
@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    _dataSource = @[
                //跳转系统设置根目录中的项目使用如下的方法：
               @{@"系统设置":@"prefs:root=INTERNET_TETHERING"},
               @{@"WIFI设置":@"prefs:root=WIFI"},
               @{@"蓝牙设置":@"prefs:root=Bluetooth"},
               @{@"系统通知":@"prefs:root=NOTIFICATIONS_ID"},
               @{@"通用设置":@"prefs:root=General"},
               @{@"显示设置":@"prefs:root=DISPLAY&BRIGHTNESS"},
               @{@"壁纸设置":@"prefs:root=Wallpaper"},
               @{@"声音设置":@"prefs:root=Sounds"},
               @{@"隐私设置":@"prefs:root=privacy"},
               @{@"APP Store":@"prefs:root=STORE"},
               @{@"Notes":@"prefs:root=NOTES"},
               @{@"Safari":@"prefs:root=Safari"},
               @{@"Music":@"prefs:root=MUSIC"},
               @{@"photo":@"prefs:root=Photos"},
               
               //如果需要继续向项目内层进行跳转，可以通过添加path路径的方式，如下：
               @{@"关于本机":@"prefs:root=General&path=About"},
               @{@"软件升级":@"prefs:root=General&path=SOFTWARE_UPDATE_LINK"},
               @{@"日期时间":@"prefs:root=General&path=DATE_AND_TIME"},
               @{@"Accessibility":@"prefs:root=General&path=ACCESSIBILITY"},
               @{@"键盘设置":@"prefs:root=General&path=Keyboard"},
               @{@"VPN":@"prefs:root=General&path=VPN"},
               @{@"壁纸设置":@"prefs:root=Wallpaper"},
               @{@"声音设置":@"prefs:root=Sounds"},
               @{@"隐私设置":@"prefs:root=privacy"},
               @{@"APP Store":@"prefs:root=STORE"},
               @{@"还原设置":@"prefs:root=General&path=Reset"},
               //跳转到应用通知， 后面需设置目标的boundldId
               @{@"应用通知":@"prefs:root=NOTIFICATIONS_ID&path=应用的boundleId"}
               ];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSURL * url = [NSURL URLWithString:[_dataSource[indexPath.row] allValues].firstObject];
    [[UIApplication sharedApplication]openURL:url];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataSource.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"reuseIdentifier"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"reuseIdentifier"];
    }
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"reuseIdentifier" forIndexPath:indexPath];
    
    // Configure the cell...
//    NSLog(@"%ld", indexPath.row);
    cell.textLabel.text = [_dataSource[indexPath.row] allValues].firstObject;
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
